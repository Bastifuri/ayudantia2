
package com.mycompany.ayudantia2;

import java.util.ArrayList;

public class Desarrollador extends Empleado {
    
    ArrayList<String>lenguajes;
    
    public Desarrollador(String nombre, int salario, ArrayList<String>lenguajes){
    super(nombre, salario,"Desarollador");
    this.lenguajes = lenguajes;
            }

    public ArrayList<String> getLenguajes() {
        return lenguajes;
    }

    public void setLenguajes(ArrayList<String> lenguajes) {
        this.lenguajes = lenguajes;
    }
}
