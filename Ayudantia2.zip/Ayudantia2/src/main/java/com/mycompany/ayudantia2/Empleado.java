package com.mycompany.ayudantia2;

public abstract class Empleado {
        private String nombre;
        private int salario;
        private String cargo;
        
        public Empleado (){}
        public Empleado(String nombre, int salario, String cargo){
        this.nombre = nombre;
        this.cargo = cargo;
        this.salario = salario;
        }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getSalario() {
        return salario;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    }

