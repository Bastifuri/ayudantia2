
package com.mycompany.ayudantia2;
import java.util.ArrayList;

public class Diseñador extends Empleado {
    ArrayList<String>Herramientas;
    
    public Diseñador(String nombre, int salario, ArrayList<String>Herramientas){
    super(nombre, salario, "Diseñador");
    this.Herramientas = Herramientas;
    }

    public ArrayList<String> getHerramientas() {
        return Herramientas;
    }

    public void setHerramientas(ArrayList<String> Herramientas) {
        this.Herramientas = Herramientas;
    }
}
